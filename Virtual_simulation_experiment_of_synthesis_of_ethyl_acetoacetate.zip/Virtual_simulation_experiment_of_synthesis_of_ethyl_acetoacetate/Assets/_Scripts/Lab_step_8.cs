﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Lab_step_8 : MonoBehaviour
{


    public DraughtCupboardDoor doorLeft;
    public DraughtCupboardDoor doorRight;
    public GameObject magnifierCamera;
    public ExperimentOperation[] experimentOperation;
    private int opNum;

    private Lab_UIManager UIManager;
    private AnimationUtils animationUtils;
    private int state;

    private float minFov = 5f;
    private float maxFov = 100f;
    private float defaultFov = 60f;
    private float sensitivity = 30f;
    private bool isPlayingAnim;
    private bool hasSelected;
    private bool isLocked = true;
    private AudioManager audioManager;
    private bool doseSelectionIsOpened = false;
    private bool multiSelectionIsOpened = false;
    private int shakeNumber;

    void Start()
    {


        Camera.main.fieldOfView = defaultFov;
        Camera camera = magnifierCamera.GetComponent<Camera>();
        camera.enabled = false;

        audioManager = GetComponent<AudioManager>();
        hasSelected = false;
        isPlayingAnim = false;
        state = 0;
        shakeNumber = 0;
        opNum = experimentOperation.Length;
        UIManager = GetComponent<Lab_UIManager>();
        animationUtils = GetComponent<AnimationUtils>();
        animationUtils.HideRoadPoints(experimentOperation);
        UIManager.UpdateInfo(new string[] { "实验第七部分开始", "请关闭真空泵并拆卸导管" });
    }

    private void Update()
    {
        bool isMouseDown = Input.GetMouseButtonDown(0);
        bool isMouseUp = Input.GetMouseButtonUp(0);
        if ((isMouseDown || isMouseUp) && !doseSelectionIsOpened && !multiSelectionIsOpened)    //点击鼠标左键时，利用射线检测Equipment层的物体
        {
            if (state == -1)
            {
                SceneManager.LoadScene("Lab_6");
                //Debug.Log("to scene step_6");
                return;
            }
            RaycastHit hitInfo;
            Vector2 screenMidPoint = new Vector2(Screen.width / 2, Screen.height / 2);
            LayerMask mask = 1 << (LayerMask.NameToLayer("Equipment"));//layer为枚举
            if (Physics.Raycast(Camera.main.ScreenPointToRay(screenMidPoint), out hitInfo, 64, mask.value))
            {
                string name = hitInfo.collider.name;
                if (name.Equals("doorLeft") || name.Equals("doorRight"))
                {
                    if (isMouseUp)
                    {
                        DraughtCupboardDoor door = hitInfo.collider.gameObject.GetComponent<DraughtCupboardDoor>();
                        door.OnMyMouseDown();
                    }
                }
                else
                {
                    Debug.Log(name);
                    RaycastResultJudge(hitInfo);
                }
            }
        }


        if (Input.GetMouseButtonDown(1))
        {
            Camera.main.fieldOfView = defaultFov;
            Camera camera = magnifierCamera.GetComponent<Camera>();
            camera.enabled = !camera.enabled;
        }

        float fov = Camera.main.fieldOfView;
        fov += Input.GetAxis("Mouse ScrollWheel") * -sensitivity;
        fov = Mathf.Clamp(fov, minFov, maxFov);
        Camera.main.fieldOfView = fov;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isLocked)
            {
                isLocked = false;
                UIManager.firstPersonController.m_MouseLook.lockCursor = false;
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else
            {
                isLocked = true;
                UIManager.firstPersonController.m_MouseLook.lockCursor = true;
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }

        //if (UIManager.multiSelectionIsConfirmed)
        //{
        //    multiSelectionIsOpened = false;
        //    UIManager.multiSelectionIsConfirmed = false;
        //    string myChoice = UIManager.multiSelectionMyChoice;
        //    bool isCorrect = false;
        //    switch (state)
        //    {
        //        case 4:
        //            if (myChoice.Equals("支管口处"))
        //            {
        //                isCorrect = true;
        //            }
        //            break;
        //        case 8:
        //            if (myChoice.Equals("下进上出"))
        //            {
        //                isCorrect = true;
        //            }
        //            break;
        //    }
        //    if (isCorrect)
        //    {
        //        audioManager.PlayAudioCorrect();
        //        if (state == 8)
        //        {
        //            rope_eq_to_water.SetActive(true);
        //            rope_water_to_eq.SetActive(true);
        //            waterZhiXingLengNingGuan.SetActive(true);
        //            OnAnimationFinished();
        //        }
        //        else
        //        {
        //            PlayAnimation();
        //        }
        //    }
        //    else
        //    {
        //        Invoke("OnWrongTip", 1f);
        //        audioManager.PlayAudioWrong();
        //    }
        //}

        //if (UIManager.doseSelectionHasConfirmed == true)
        //{
        //    doseSelectionIsOpened = false;
        //    UIManager.doseSelectionHasConfirmed = false;
        //    float allowableDeviation = 0.1f;        //允许最大偏差10%
        //    float targetValue = float.MaxValue;
        //    switch (state)
        //    {
        //        case 4:                                                     //将2.5g钠加入圆底烧瓶
        //            targetValue = 2.5f;
        //            break;
        //        case 8:
        //            targetValue = 12.5f;                                    //将12.5ml二甲苯加入圆底烧瓶
        //            break;
        //        default:
        //            Debug.Log("error state");
        //            break;
        //    }
        //    if (Mathf.Abs(targetValue - UIManager.doseSelectionValue) / targetValue <= allowableDeviation)  //误差在10%以内
        //    {
        //        PlayAnimation();
        //        audioManager.PlayAudioCorrect();
        //        if (state == 8)
        //            Invoke("Case_8_Delay_Func", 2.5f);
        //    }
        //    else
        //    {
        //        audioManager.PlayAudioWrong();
        //        Invoke("OnWrongTip", 1f);
        //    }
        //}
    }

    //void OnWrongTip()
    //{
    //    if (state==4)
    //        UIManager.UpdateInfo(new string[] { "温度计水银球位置选择错误", "请重新选择" });
    //    if (state == 8)
    //        UIManager.UpdateInfo(new string[] { "选择的通冷凝水的方法错误", "请重新选择" });
        
    //}



    void RaycastResultJudge(RaycastHit hitInfo)
    {
        if (hasSelected == false)
        {
            switch (state)
            {
                case 1:
                    if (hitInfo.collider.name.Equals("buShiLouDou"))
                    {
                        hasSelected = true;
                    }
                    break;
                
            }
            if (hasSelected)
            {
                UIManager.OnCorrectChoose();
            }
            else
            {
                UIManager.OnWrongChoose();
            }
        }
        else // hasSelected = true
        {
            switch (state)
            {
                case 1:
                    if (hitInfo.collider.name.Equals("tableMat"))
                    {
                        PlayAnimation();
                        hasSelected = false;
                    }
                    break;
                
            }
            if (hasSelected == false)
            {
                UIManager.OnCorrectChoose();
            }
            else
            {
                hasSelected = false;
                UIManager.OnWrongChoose();
            }
        }
    }


    void OnAnimationStart() {}

    void PlayAnimation()
    {
        if (!isPlayingAnim)
        {
            isPlayingAnim = true;
            OnAnimationStart();                                             //播放动画前的操作
            animationUtils.PlayAnimations(experimentOperation, state);      //播放动画
            
            //Invoke("OnAnimationFinished", animationUtils.currAnimDuration);     //播放动画后的操作
            float timeSum = 0f;
            for (int i = 0; i < experimentOperation[state].animationItem.Length; i++)
            {
                timeSum += experimentOperation[state].animationItem[i].animDuration;
            }
            Invoke("OnAnimationFinished", timeSum);     //播放动画后的操作
        }
    }

    void OnAnimationFinished()
    {
        isPlayingAnim = false;
        state++;
        string str = string.Empty;
        switch (state)
        {
            case 1:
                str = "请拆卸布氏漏斗";
                break;
            
            //case 10:
            //    str = "常压蒸馏一段时间后，把乙酸乙酯这样的低沸点液体蒸馏出来";
            //    Invoke("state_10_delay_fun", 7f);
            //    break;
        }
        UIManager.UpdateInfo(str);
    }
    

}

#if false



#endif