using UnityEngine;
using System.Collections;

public class UltimateRopeLink : MonoBehaviour
{
    public bool ExtensibleKinematic = false;
}
